import Apps from './Apps';
const Component = () => {
    return <div>
        <Apps />
    </div>
};
export default Component;